/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genetic;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import static java.util.concurrent.TimeUnit.SECONDS;

/**
 *
 * @author mvelase
 */
public class PythonCaller {

    private static long TIMEOUT;

    /**
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        try {
            int i = 0;
            String prg = "space /Users/mvelase/Documents/stuff/MalwareDetection/test1.py";
            String arg = "/Users/mvelase/Documents/stuff/MalwareDetection/test/malicious.exe";
            
            String prg1 = prg + " " + arg;
            String ret = "initial";
            System.out.println(prg1); String x ="x";
          // ProcessBuilder pb = new ProcessBuilder("python", prg1);
            ProcessBuilder pb = new ProcessBuilder("python", "/Users/mvelase/Documents/stuff/MalwareDetection/test.py",arg);
            Process p = pb.start();
            
         
            System.out.println("I have started");
            p.waitFor();
            //read till end of line, wait
            TimeUnit.SECONDS.sleep(50);
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
           // ret = in.readLine();
            System.out.println(in);
            System.out.println("I have started too");
//            while ((ret = in.readLine()) == null) {
//
//                System.out.println(i);
//                TimeUnit.SECONDS.sleep(5);
//                // p.waitFor(10, SECONDS);
//                //  ret = new String(in.readLine());
//
//                ++i;
//                in = new BufferedReader(new InputStreamReader(p.getInputStream()));
//                ret = in.readLine();
//
//            }

            //in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            // ret = new String(in.readLine());
            System.out.println("value is : " + ret);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
