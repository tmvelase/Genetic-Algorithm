/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genetic;

/**
 *
 * @author mvelase
 */
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
/**
 *
 * @author NOZITHELO NCUBE
 */
public class Anealing {

    public static int[] Evaluate(int[] a){
        
        
        int pos = ThreadLocalRandom.current().nextInt(0, 6);
        int[] b= a;
        if (b[pos]==1){
            b[pos]=0;
        }
        else
            b[pos]=1;
        
        return b;
    }
    public static int[] createArray(){
       
    int[] arr= new int[6];
    int n = ThreadLocalRandom.current().nextInt(2);
     //Random rand = new Random();
     //int n = rand.nextInt(2);
    
    for (int i=0;i<6;i++){
        arr[i]=ThreadLocalRandom.current().nextInt(2);
       
        }
    return arr; 
    }
    
    public static int Fitness(int[] x){
        int[] z= x;
        int fitnessScore=0;
        
        for(int count=0;count<6;count++){
            if(z[count]==1)
                fitnessScore++;
        }
        
        return fitnessScore;
        
    }
    
    
            
    
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
    int[] trial = new int[6];
    int [] result= new int[6];
    
    int fitScore=0;
    int fitScore1=0;
    int fitScore2=0;
    int fitScore3=0;
    
    
    int[] answer= new int[6];
    int[] answerOne= new int[6];
    int[] answerTwo= new int[6];
    int[] answerThree= new int[6];
    
    int[] VN=new int[6];
    int[] incrVN= new int[6];
    
    //int[] copyArray = Arrays.copyOf(result, result.length);
    result=createArray();
    while (fitScore!=6){
    System.out.println("Initial array is "+Arrays.toString(result)); 
    trial = Arrays.copyOf(result, result.length);
    fitScore = Fitness(trial);
    System.out.println("Initial array fitness is "+fitScore+"\n");
    
    //int[] tester= new int[6];
   //tester = Evaluate(copyArray);
   
    
    System.out.println("Initial array is "+Arrays.toString(result));
    answerOne = Arrays.copyOf(Evaluate(result), 6);
    System.out.println("Your neighbour number 1 is:"+Arrays.toString(answerOne));
    fitScore1 = Fitness(answerOne);
    System.out.println("Neighbour fitness is "+fitScore1+" \n");
    
    
    result=Arrays.copyOf(trial, trial.length);
    System.out.println("Initial array is "+Arrays.toString(result));
    answerTwo = Arrays.copyOf(Evaluate(result), 6);
    System.out.println("Your neighbour number 2 is:"+Arrays.toString(answerTwo));
    fitScore2 = Fitness(answerTwo);
    System.out.println("Neighbour fitness is "+fitScore2+" \n"); 
   
   
   
   result=Arrays.copyOf(trial, trial.length);
    System.out.println("Initial array is "+Arrays.toString(result));
    answerThree = Arrays.copyOf(Evaluate(result), 6);
    System.out.println("Your neighbour number 3 is:"+Arrays.toString(answerThree));
    //System.out.println("Your neighbour number 2 is:"+Arrays.toString(Evaluate(result)));
    fitScore3 = Fitness(answerThree);
    System.out.println("Neighbour fitness is "+fitScore3+" \n"); 
    
    
    
    if(fitScore1<fitScore2){
        if(fitScore2<fitScore3)
        VN=Arrays.copyOf(answerThree,6);
     System.out.println(Arrays.toString(VN)); 
    }else if(fitScore1>=fitScore2){
         if(fitScore1>=fitScore3)
             VN=Arrays.copyOf(answerOne,6);
            }  
        else
            VN=Arrays.copyOf(answerTwo,6);
    
    System.out.println("VN is"+Arrays.toString(VN));
    
    int fitnessVN;
    fitnessVN=Fitness(VN);
    
    if (fitScore<fitnessVN)
        incrVN=Arrays.copyOf(VN, 6);
    else
        incrVN=Arrays.copyOf(trial, 6);
    System.out.println("Vc is now "+Arrays.toString(incrVN));
    
    }
    
    } 
  
    
}
        //output = Arrays.stream(result).collect(Collectors.joining(","));
