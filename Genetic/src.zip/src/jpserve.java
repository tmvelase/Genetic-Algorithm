
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.xdevelop.jpclient.PyResult;
import net.xdevelop.jpclient.PyServeContext;
import net.xdevelop.jpclient.PyServeException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mvelase
 */
public class jpserve {
    
    public static void main(String[] args) {
        try {
            PyServeContext.init("localhost", 8881);
         
String f = "src/test/java/net/xdevelop/jpclient/test/helloworld.py";
PyResult rs = PyServeContext.getExecutor().exec(f);

InputStream in = ClientSample.class.getResourceAsStream("helloworld.py");
 rs = PyServeContext.getExecutor().exec(in);
        } 
        
catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
}
